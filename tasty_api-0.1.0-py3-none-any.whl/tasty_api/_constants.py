from typing import Final

TASTY_HOST: Final[str] = "tasty.p.rapidapi.com"
